package com.railway.exceptions;

public class ResourceAlreadyExistException extends Exception {

	public ResourceAlreadyExistException(String msg)
	{
		super(msg);
	}
}
