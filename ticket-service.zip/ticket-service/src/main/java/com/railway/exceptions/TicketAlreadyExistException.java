package com.railway.exceptions;

public class TicketAlreadyExistException extends Exception {

}
