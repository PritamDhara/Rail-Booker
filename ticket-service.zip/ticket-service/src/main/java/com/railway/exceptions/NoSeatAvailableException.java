package com.railway.exceptions;

public class NoSeatAvailableException extends Exception {

}
