package com.railway.exceptions;

public class NoTicketsAvailableException extends Exception{

}
