package com.railway.exceptions;

public class TicketNotFoundWithThePNRException extends Exception{

}
