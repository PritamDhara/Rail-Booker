package com.railway.entity;

import lombok.Data;

@Data

public class Passenger {
	
	private String name;
	private String mobileNo;
	private int age;
	private String aadhar;

}
