package com.railway.client;

public interface UserClient {

}
